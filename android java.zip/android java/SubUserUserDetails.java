package com.example.deepak.projectpart1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SubUserUserDetails extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_user_user_details);
        final Spinner spinner = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr2);
        final Spinner spinner2 = (Spinner) findViewById(R.id.spnr3);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Service_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Religion_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.Cast_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        /*db = FirebaseFirestore.getInstance();

        edtfname = findViewById(R.id.userdetailsfname);
        edtmname = findViewById(R.id.userdetailsmname);
        edtlname = findViewById(R.id.userdetailslname);
        edtfathername = findViewById(R.id.userdetailsfathername);
        edtmothername = findViewById(R.id.userdetailsmothername);
        edtage = findViewById(R.id.userdetailsage);
        edtbirth = findViewById(R.id.userdetailsbirthplace);


        findViewById(R.id.userdetailsbtnvalue).setOnClickListener(UserDetails.this);
*/      final EditText edtfname=(EditText)findViewById(R.id.subuserdetailsfname);
        final EditText edtmname=(EditText)findViewById(R.id.subuserdetailsmname);
        final EditText edtlname=(EditText)findViewById(R.id.subuserdetailslname);
        final EditText editfathername = (EditText)findViewById(R.id.subuserdetailsfathername);
        final EditText editmothername = (EditText)findViewById(R.id.subuserdetailsmothername);
        final EditText edtage=(EditText)findViewById(R.id.subuserdetailsage);
        final EditText edtbirth =(EditText)findViewById(R.id.subuserdetailsbirthplace);
        Button btnsend=(Button)findViewById(R.id.subbtnvalue);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user= FirebaseAuth.getInstance().getCurrentUser();
        final String uid=current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/personaldetails").child(uid).child("UserDetails");
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("First Name").setValue(edtfname.getText().toString());
                myref.child("Middle Name").setValue(edtmname.getText().toString());
                myref.child("Last Name").setValue(edtlname.getText().toString());
                myref.child("Father's Name").setValue(editfathername.getText().toString());
                myref.child("Mother's Name").setValue(editmothername.getText().toString());
                myref.child("Age").setValue(edtage.getText().toString());
                myref.child("Birth Place").setValue(edtbirth.getText().toString());
                myref.child("Service").setValue(spinner.getSelectedItem().toString());
                myref.child("Religion").setValue(spinner1.getSelectedItem().toString());
                myref.child("Cast").setValue(spinner2.getSelectedItem().toString());
            }
        });
    }
    /*private boolean validateInputs(String fname, String mname, String lname, String fathername, String mothername, String age, String birthplace) {
      if (fname.isEmpty()) {
          edtfname.setError("Name required");
          edtfname.requestFocus();
          return true;
      }
      if (mname.isEmpty()) {
          edtmname.setError("Name required");
          edtmname.requestFocus();
          return true;
      }
      if (lname.isEmpty()) {
          edtlname.setError("Name required");
          edtlname.requestFocus();
          return true;
      }
      if (fathername.isEmpty()) {
          edtfathername.setError("Father name required");
          edtfathername.requestFocus();
          return true;
      }

      if (mothername.isEmpty()) {
          edtmothername.setError("Mother name required");
          edtmothername.requestFocus();
          return true;
      }

      if (age.isEmpty()) {
          edtage.setError("age required");
          edtage.requestFocus();
          return true;
      }

      if (birthplace.isEmpty()) {
          edtbirth.setError("Birth place required");
          edtbirth.requestFocus();
          return true;
      }
      return false;
  }
*/
    @Override
    public void onClick(View v) {

    }

 /*   @Override
    public void onClick(View v) {

        String fname = edtfname.getText().toString().trim();
        String mname = edtmname.getText().toString().trim();
        String lname = edtlname.getText().toString().trim();
        String fathername = edtfathername.getText().toString().trim();
        String mothername = edtmothername.getText().toString().trim();
        String age = edtage.getText().toString().trim();
        String birth = edtbirth.getText().toString().trim();

        if (!validateInputs(fname,mname,lname, fathername, mothername, age, birth)) {

            CollectionReference dbFirstUserDetails = db.collection("FirstUserDetails");
            FirstUserDetails firstUserDetails = new FirstUserDetails(
                    fname,
                    mname,
                    lname,
                    fathername,
                    mothername,
                    birth,
                    Integer.parseInt(age)
            );

            dbFirstUserDetails.add(firstUserDetails)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Toast.makeText(UserDetails.this, "User Added", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(UserDetails.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

        }

    }*/
}
