package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.google.protobuf.Empty;

public class ConfirmPassword extends AppCompatActivity {
EditText e1,e2;
Button btnpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_password);
        e1 = findViewById(R.id.editpassword);
        e2 = findViewById(R.id.editconfirmpassword);
        btnpassword = findViewById(R.id.confirmpasswordsave);
btnpassword.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String password,confirm;
        password =e1.getText().toString().trim();
        confirm = e2.getText().toString().trim();

        if(!password.isEmpty() && !confirm.isEmpty()){
            updateUI(password,confirm);
        }else{
            Toast.makeText(ConfirmPassword.this,"please fill all fields",Toast.LENGTH_SHORT).show();
        }
    }
});

    }
private void updateUI(String password, String confirm) {
if (password.equals(confirm))
{
    startActivity(new Intent(ConfirmPassword.this,Login.class));

}
else if (password.isEmpty() || confirm.isEmpty()){
    Toast.makeText(this,"Error",Toast.LENGTH_LONG);
}
    }
}
