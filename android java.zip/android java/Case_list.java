package com.example.deepak.projectpart1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Case_list extends AppCompatActivity {

    private LinearLayoutManager mlayoutManager;
    private List<ModelClass> item_list;
    private RecyclerAdapter mrecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler1);
        item_list = new ArrayList<>();
        mrecyclerAdapter = new RecyclerAdapter(this, item_list);
        mlayoutManager = new LinearLayoutManager(this);
        recyclerView.setAdapter(mrecyclerAdapter);
        recyclerView.setLayoutManager(mlayoutManager);
        for (int i = 1; i <= 10; i++) {
            item_list.add(new ModelClass("Case ID", "", "Priority", "", "Complain by", ""));
        }
    }
}
