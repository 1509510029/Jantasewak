package com.example.deepak.projectpart1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toolbar;

public class MainUserSetting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user_setting);
        Spinner spinner = (Spinner) findViewById(R.id.spnr1);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.BodyManagement_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

    public void click(View view) {
        Intent i=new Intent(MainUserSetting.this,Marked2.class);
        startActivity(i);
    }

    public void EditSubUser(View view) {
        Intent i=new Intent(MainUserSetting.this,Edit_sub_User.class);
        startActivity(i);
    }

    public void GalleryClick(View view) {
        Intent i=new Intent(MainUserSetting.this,Gallery.class);
        startActivity(i);
    }

    public void SettingClick(View view) {
        Intent i=new Intent(MainUserSetting.this,SettingsActivity.class);
        startActivity(i);
    }
}