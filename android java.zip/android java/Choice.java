package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Choice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);
    }

    public void adminclick(View view) {
    Intent i=new Intent(Choice.this,PersonalDetails.class);
    startActivity(i);
    }

    public void Subclick(View view) {
        Intent i=new Intent(Choice.this,SubUserPersonalDetails.class);
        startActivity(i);
    }

    public void userclick(View view) {
        Intent i=new Intent(Choice.this,UserPersonalDetails.class);
        startActivity(i);
    }
}
