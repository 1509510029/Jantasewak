package com.example.deepak.projectpart1;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class User_Login extends AppCompatActivity {
    TextView tv,tv1;
    Calendar mCurrentDate;
    int day, month, year;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__login);

            Spinner spinner1 = (Spinner) findViewById(R.id.spnr2);
            Spinner spinner2 = (Spinner) findViewById(R.id.spnr3);
            Spinner spinner3 = (Spinner) findViewById(R.id.spnr4);
            Spinner spinner4 = (Spinner) findViewById(R.id.spnr5);
            Spinner spinner5 = (Spinner) findViewById(R.id.spnr6);
            Spinner spinner6 = (Spinner) findViewById(R.id.spnr7);
            Spinner spinner7 = (Spinner) findViewById(R.id.spnr8);
            // Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.District_array, android.R.layout.simple_spinner_item);
            ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.State_array, android.R.layout.simple_spinner_item);
            ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this, R.array.Religion_array, android.R.layout.simple_spinner_item);
            ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this, R.array.Cast_array, android.R.layout.simple_spinner_item);
            ArrayAdapter<CharSequence> adapter7 = ArrayAdapter.createFromResource(this, R.array.Marital_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
            adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            adapter7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
            spinner1.setAdapter(adapter1);
            spinner2.setAdapter(adapter2);
            spinner3.setAdapter(adapter1);
            spinner4.setAdapter(adapter2);
            spinner5.setAdapter(adapter5);
            spinner6.setAdapter(adapter6);
            spinner7.setAdapter(adapter7);

            tv = findViewById(R.id.btn1);
            tv1 = findViewById(R.id.btn2);

            mCurrentDate = Calendar.getInstance();

            day = mCurrentDate.get(Calendar.DAY_OF_MONTH);
            month = mCurrentDate.get(Calendar.MONTH);
            year = mCurrentDate.get(Calendar.YEAR);

            month = month+1;

            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    DatePickerDialog datePickerDialog = new DatePickerDialog(User_Login.this, new DatePickerDialog.OnDateSetListener() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth){
                            monthOfYear = monthOfYear+1;
                            tv.setText(dayOfMonth+"/"+monthOfYear+"/"+year);
                        }
                    }, year, month, day);
                    datePickerDialog.show();
                }
            });
            tv1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                    DatePickerDialog datePickerDialog = new DatePickerDialog(User_Login.this, new DatePickerDialog.OnDateSetListener() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth){
                            monthOfYear = monthOfYear+1;
                            tv1.setText(dayOfMonth+"/"+monthOfYear+"/"+year);
                        }
                    }, year, month, day);
                    datePickerDialog.show();
                }
            });
    }

    public void click(View view) {
        Intent i=new Intent(this,End_user.class);
        startActivity(i);
    }
}
