package com.example.deepak.jantalogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonSignin;
    private EditText editTextEmail;
    private EditText editTextpassword;
    private TextView textViewSignup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonSignin=(Button) findViewById(R.id.buttonSign);
        editTextEmail = (EditText) findViewById(R.id.editTextEmailId);
        editTextpassword = (EditText) findViewById(R.id.editTextPassword);
        textViewSignup = (TextView) findViewById(R.id.textViewlink_signup);
        buttonSignin.setOnClickListener(this);
        textViewSignup.setOnClickListener(this);

        buttonSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +

                        "\\@" +

                        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +

                        "(" +

                        "\\." +

                        "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +

                        ")+";
                String email=editTextEmail.getText().toString();
                Matcher matcher= Pattern.compile(validemail).matcher(email);
                if(matcher.matches()){
                    loginUser();
                    //Toast.makeText(getApplicationContext(),"true",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Enter valid Mail",Toast.LENGTH_LONG).show();
                }if (editTextpassword.getText().toString().equals("")){
                    editTextpassword.setError("Enter Password");
                }
            }
        });
    }
    private void loginUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextpassword.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            //email is empty
            Toast.makeText(this, "please enter email", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }
        if (TextUtils.isEmpty(password) || password.length() < 8) {
            //email is empty
            Toast.makeText(this, "please enter correct password", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }
    }
    public void click(View view) {
        Intent i=new Intent(this,Mainpage.class);
        startActivity(i);
    }


    @Override
    public void onClick(View view) {

    }
}
