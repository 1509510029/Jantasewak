package com.example.deepak.projectpart1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class SubUserPersonalDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_user_personal_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void subUserDetails(View view) {
        Intent i=new Intent(this,SubUserUserDetails.class);
        startActivity(i);
    }

    public void subAddress(View view) {
        Intent i=new Intent(this,SubUserAddress.class);
        startActivity(i);
    }

    public void subContactDetails(View view) {
        Intent i=new Intent(this,SubUserContactDetails.class);
        startActivity(i);
    }

    public void subOnlineDetails(View view) {
        Intent i=new Intent(this,SubUserOnlineDetails.class);
        startActivity(i);
    }

    public void btnsave(View view) {
        Intent i=new Intent(this,SubUserOnlineDetails.class);
        startActivity(i);
    }
}