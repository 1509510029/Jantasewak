package com.example.deepak.projectpart1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EducationalDetails extends AppCompatActivity {
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Button buttoneduaction = (Button)findViewById(R.id.edusave);
        final EditText editText3=(EditText)findViewById(R.id.highestedu);
        final EditText editText4=(EditText)findViewById(R.id.professionalquali);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/educationaldetails").child(uid).child("Address");
        buttoneduaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("Highest Qualifiaction").setValue(editText3.getText().toString());
                myref.child("Professional Qualification").setValue(editText4.getText().toString());
            }
        });
    }

    public void HighSchool(View view) {
        Intent i=new Intent(this,HighSchool.class);
        startActivity(i);
    }
    public void Intermediate(View view) {
        Intent i=new Intent(this,Intermediate.class);
        startActivity(i);
    }

    public void Graduation(View view) {
        Intent i=new Intent(this,Graduation.class);
        startActivity(i);
    }

    public void PostGraduation(View view) {
        Intent i=new Intent(this,PostGraduation.class);
        startActivity(i);
    }

}
