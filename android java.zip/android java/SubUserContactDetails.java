package com.example.deepak.projectpart1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SubUserContactDetails extends AppCompatActivity {
    private LinearLayout mLayout;
    private LinearLayout m1Layout;
    private LinearLayout m2Layout;
    ImageButton additem;
    ImageButton additem1;
    ImageButton additem2;
    Button buttoncontact;
    EditText editText1;
    EditText editText2;
    EditText editText3;
    DynamicView dnv;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_user_contact_details);

        Button buttoncontact = (Button)findViewById(R.id.Contactsave);
        final EditText editText1 = (EditText)findViewById(R.id.subeditcontact1);
        final EditText editText2 = (EditText)findViewById(R.id.subeditcontact2);
        final EditText editText3 = (EditText)findViewById(R.id.subeditcontact3);
        mLayout = (LinearLayout)findViewById(R.id.linear1);
        m1Layout = (LinearLayout)findViewById(R.id.linear2);
        m2Layout = (LinearLayout)findViewById(R.id.linear3);
        additem = (ImageButton)findViewById(R.id.subContactadd1);
        additem1 = (ImageButton)findViewById(R.id.subworknoadd1);
        additem2 = (ImageButton)findViewById(R.id.subresidencenoadd1);

        additem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dnv = new DynamicView(context);
                mLayout.addView(dnv.recievedQuantityEditText(getApplicationContext()),2);
            }
        });
        additem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dnv = new DynamicView(context);
                m1Layout.addView(dnv.recievedQuantityEditText(getApplicationContext()),2);
            }
        });

        additem2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dnv = new DynamicView(context);
                m2Layout.addView(dnv.recievedQuantityEditText(getApplicationContext()),2);
            }
        });
        buttoncontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savenumber();
            }
        });
        FirebaseDatabase database= FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/SubUserpersonaldetails").child(uid).child("Contact");
        buttoncontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("Mobile number").setValue(editText1.getText().toString());
                myref.child("Work number").setValue(editText2.getText().toString());
                myref.child("Residence number").setValue(editText3.getText().toString());
            }
        });
    }

    private void savenumber(){
        String number1= editText1.getText().toString().trim();
        String number2 = editText2.getText().toString().trim();
        String number3= editText3.getText().toString().trim();
        if(TextUtils.isEmpty(number1) || TextUtils.isEmpty(number2)|| TextUtils.isEmpty(number3)){
            //email is empty
            Toast.makeText(this,"please fill all details ",Toast.LENGTH_LONG).show();
            //stopping the function execution further
            return;

        }
        else{
            Intent i=new Intent(this,PersonalDetails.class);
            startActivity(i);
        }
    }
}
