package com.example.deepak.projectpart1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Online extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online);

        final EditText edtwhats=(EditText)findViewById(R.id.onlinewhatsup);
        final EditText edtmmail=(EditText)findViewById(R.id.onlineemail);
        final EditText edtlfb=(EditText)findViewById(R.id.onlinefacebook);
        final EditText edittwitter = (EditText)findViewById(R.id.onlinetwitter);
        final EditText editwebsite = (EditText)findViewById(R.id.onlinewebsite);
        Button btnonline=(Button)findViewById(R.id.onlinebtnsave);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user= FirebaseAuth.getInstance().getCurrentUser();
        final String uid=current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/personaldetails").child(uid).child("Online");
        btnonline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("Whatsapp number").setValue(edtwhats.getText().toString());
                myref.child("Email ID").setValue(edtmmail.getText().toString());
                myref.child("Facebook").setValue(edtlfb.getText().toString());
                myref.child("Twitter").setValue(edittwitter.getText().toString());
                myref.child("Website").setValue(editwebsite.getText().toString());
            }
        });
    }
}
