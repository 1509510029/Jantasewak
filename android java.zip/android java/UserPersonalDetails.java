package com.example.deepak.projectpart1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class UserPersonalDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_personal_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }
    public void UserDetails(View view) {
        Intent i=new Intent(this,User_userdetails.class);
        startActivity(i);
    }

    public void Address(View view) {
        Intent i=new Intent(this,UserAddress.class);
        startActivity(i);
    }

    public void ContactDetails(View view) {
        Intent i=new Intent(this,Contact.class);
        startActivity(i);
    }

    public void OnlineDetails(View view) {
        Intent i=new Intent(this,Online.class);
        startActivity(i);
    }
}
