package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PostGraduation extends AppCompatActivity {
    Button buttonpost;
    EditText editText1;
    EditText editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_graduation);

        Button buttonpost = (Button)findViewById(R.id.savepost);
        editText1 = (EditText)findViewById(R.id.postuniversity);
        editText2 = (EditText)findViewById(R.id.postpercent);

        final EditText editText3=(EditText)findViewById(R.id.postuniversity);
        final EditText editText4=(EditText)findViewById(R.id.postpercent);
        final Spinner spinner = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr2);
        final Spinner spinner2 = (Spinner) findViewById(R.id.spnr3);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.YearPassing_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Degree_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.Branch_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/educationaldetails").child(uid).child("PostGraduation");        buttonpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savepostgraduation();
                myref.child("University").setValue(editText3.getText().toString());
                myref.child("Post Graduation percent").setValue(editText4.getText().toString());
                myref.child("Year of passing").setValue(spinner.getSelectedItem().toString());
                myref.child("Degree").setValue(spinner1.getSelectedItem().toString());
                myref.child("Branch").setValue(spinner2.getSelectedItem().toString());
            }
        });
    }
    private void savepostgraduation(){
        String university= editText1.getText().toString().trim();
        String percent = editText2.getText().toString().trim();
        if(TextUtils.isEmpty(university) || TextUtils.isEmpty(percent)){
            //email is empty
            Toast.makeText(this,"please fill all details ",Toast.LENGTH_LONG).show();
            //stopping the function execution further
            return;

        }
        else{
            Intent i=new Intent(this,EducationalDetails.class);
            startActivity(i);
        }

    }
}