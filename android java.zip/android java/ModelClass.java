package com.example.deepak.projectpart1;

import android.widget.TextView;

public class ModelClass {
    String txt1,txt2,txt3,txt4,txt5,txt6;

    public ModelClass(String txt1, String txt2, String txt3, String txt4, String txt5, String txt6) {
        this.txt1 = txt1;
        this.txt2 = txt2;
        this.txt3 = txt3;
        this.txt4 = txt4;
        this.txt5 = txt5;
        this.txt6 = txt6;
    }

    public String getTxt1() {
        return txt1;
    }

    public void setTxt1(String txt1) {
        this.txt1 = txt1;
    }

    public String getTxt2() {
        return txt2;
    }

    public void setTxt2(String txt2) {
        this.txt2 = txt2;
    }

    public String getTxt3() {
        return txt3;
    }

    public void setTxt3(String txt3) {
        this.txt3 = txt3;
    }

    public String getTxt4() {
        return txt4;
    }

    public void setTxt4(String txt4) {
        this.txt4 = txt4;
    }

    public String getTxt5() {
        return txt5;
    }

    public void setTxt5(String txt5) {
        this.txt5 = txt5;
    }

    public String getTxt6() {
        return txt6;
    }

    public void setTxt6(String txt6) {
        this.txt6 = txt6;
    }

    /* public ModelClass(String layout1, String layout2) {
        this.layout1 = layout1;
        this.layout2 = layout2;
    }

    public String getLayout1() {
        return layout1;
    }

    public void setLayout1(String layout1) {
        this.layout1 = layout1;
    }

    public String getLayout2() {
        return layout2;
    }

    public void setLayout2(String layout2) {
        this.layout2 = layout2;
    }*/
}
