package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetOtp extends AppCompatActivity {
    private Button buttonsignin;
    private EditText editTextmail;
    //private EditText editTextphone;
    private Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_otp);
        buttonsignin = (Button) findViewById(R.id.btngetotp);
        editTextmail = (EditText) findViewById(R.id.getotpemail);
        spinner = findViewById(R.id.spinnerCountries);
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, CountryData.countryNames));

        buttonsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = CountryData.countryAreaCodes[spinner.getSelectedItemPosition()];

                String number = editTextmail.getText().toString().trim();

                if (number.isEmpty() || number.length() < 10) {
                    editTextmail.setError("Valid number is required");
                    editTextmail.requestFocus();
                    return;
                }

                String phonenumber = "+" + code + number;

                Intent intent = new Intent(GetOtp.this, SubmitOtp.class);
                intent.putExtra("phonenumber", phonenumber);
                startActivity(intent);

            }
        });

        // editTextphone = (EditText) findViewById(R.id.getotpphone);
    }
/*
    @Override
    protected void onStart() {
        super.onStart();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            Intent intent = new Intent(this, Choice.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        }
    }*/

    /*private void loginUser() {
        String email = editTextmail.getText().toString().trim();
        String phone = editTextphone.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            //email is empty
            Toast.makeText(this, "please enter email", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }else {

        }
        if (TextUtils.isEmpty(phone) || phone.length()==10) {
            //email is empty
            Toast.makeText(this, "please enter correct password", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }else {
            Intent i=new Intent(this,SubmitOtp.class);
            startActivity(i);
        }
    }*/
    public void click(View view) {
        if (view == buttonsignin) {
            String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +

                    "\\@" +

                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +

                    "(" +

                    "\\." +

                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +

                    ")+";
            String email = editTextmail.getText().toString().trim();
            //String phone = editTextphone.getText().toString().trim();

            Matcher matcher = Pattern.compile(validemail).matcher(email);
            if (matcher.matches() || email.length() ==10) {
                    //loginUser();
                    Intent i = new Intent(this, SubmitOtp.class);
                    startActivity(i);
                    //Toast.makeText(getApplicationContext(),"true",Toast.LENGTH_LONG).show();
                } else if (TextUtils.isEmpty(email)){
                    Toast.makeText(getApplicationContext(), "Enter valid Mail Or Enter valid Phone no.", Toast.LENGTH_LONG).show();
                    return;
                }
                else {
                Toast.makeText(getApplicationContext(), "Enter valid Mail Or Enter valid Phone no.", Toast.LENGTH_LONG).show();
                return;
            }

                /*if (TextUtils.isEmpty(phone) || phone.length() == 10) {
                    Intent i = new Intent(this, SubmitOtp.class);
                    startActivity(i);
                } else {
                    Toast.makeText(getApplicationContext(), "Enter valid phone Or Enter a mail ID", Toast.LENGTH_LONG).show();
                    return;
                    //editTextphone.setError("Enter Phone No.");
                }*/
            /*if (editTextphone.getText().toString().equals("")) {
                editTextphone.setError("Enter Phone No.");
            }*/
                //loginUser();
            }

        }

    }