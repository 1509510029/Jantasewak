package com.example.deepak.projectpart1;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class DynamicView {
    Context ctx;
    public final int resourceId = R.drawable.edit_round;

    public DynamicView(Context ctx) {
        this.ctx = ctx;
    }

    public EditText recievedQuantityEditText(Context context){

       final ViewGroup.LayoutParams lparams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
       final EditText editText = new EditText(context);
       int id=0;
       editText.setLayoutParams(lparams);
       editText.setId(id);
       editText.setMinEms(2);
       editText.setWidth(250);
       editText.setHeight(40);
       editText.setTextColor(Color.rgb(0,0,0));
       editText.setInputType(InputType.TYPE_CLASS_NUMBER);
       return editText;
    }
}
