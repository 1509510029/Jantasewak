package com.example.deepak.projectpart1;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateCaseForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_case_form);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner2 = (Spinner) findViewById(R.id.spnr2);
        final Spinner spinner3 = (Spinner) findViewById(R.id.spnr3);
        final Spinner spinner4 = (Spinner) findViewById(R.id.spnr4);
        // Create an ArrayAdapter using the string array and a default spinner layout
        final ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Case_type_array, android.R.layout.simple_spinner_item);
        final ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.Body_array, android.R.layout.simple_spinner_item);
        final ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.Ministry_array, android.R.layout.simple_spinner_item);
        final ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.priority_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter3);
        spinner4.setAdapter(adapter4);
        final EditText edtname=(EditText)findViewById(R.id.createcaseformname);
        final EditText edtcomplainername=(EditText)findViewById(R.id.createcaseformcomplainer);
        final EditText edtaddline1=(EditText)findViewById(R.id.createcaseformaddressline1);
        final EditText edtaddline2 = (EditText)findViewById(R.id.createcaseformaddressline2);
        final EditText edtmobileno = (EditText)findViewById(R.id.createcaseformmobileno);
        final EditText edtemail=(EditText)findViewById(R.id.createcaseformemail);
        final EditText edtmarkedto =(EditText)findViewById(R.id.createcaseformmarkedto);
        final EditText edtdesignation=(EditText)findViewById(R.id.createcaseformdesignation);
        final EditText edtaddline3=(EditText)findViewById(R.id.createcaseformaddressline3);
        final EditText edtaddline4=(EditText)findViewById(R.id.createcaseformaddressline4);
        final EditText edtmobileno2 = (EditText)findViewById(R.id.createcaseformmobileno2);
        final EditText edtofficeno = (EditText)findViewById(R.id.createcaseformofficeno);
        final EditText edtemail2=(EditText)findViewById(R.id.createcaseformemail2);
        final EditText edtcategory =(EditText)findViewById(R.id.createcaseformcategory);
        final EditText edtdescription=(EditText)findViewById(R.id.createcaseformcasedescription);
        final EditText edtlinked =(EditText)findViewById(R.id.createcaseformlinkedcase);

        Button btnsend=(Button)findViewById(R.id.createcaseformbtnsave);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/Createcaseform");
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("To jansewak").setValue(edtname.getText().toString());
                myref.child("Complainer name").setValue(edtcomplainername.getText().toString());
                myref.child("Address line1").setValue(edtaddline1.getText().toString());
                myref.child("Address line2").setValue(edtaddline2.getText().toString());
                myref.child("Mobile no").setValue(edtmobileno.getText().toString());
                myref.child("Email id").setValue(edtemail.getText().toString());
                myref.child("Marked to").setValue(edtmarkedto.getText().toString());
                myref.child("Designation").setValue(edtdesignation.getText().toString());
                myref.child("Address line 3").setValue(edtaddline3.getText().toString());
                myref.child("Address line4").setValue(edtaddline4.getText().toString());
                myref.child("Mobile no 2").setValue(edtmobileno2.getText().toString());
                myref.child("Office no").setValue(edtofficeno.getText().toString());
                myref.child("Email id 2").setValue(edtemail2.getText().toString());
                myref.child("Category").setValue(edtcategory.getText().toString());
                myref.child("Case Description").setValue(edtdescription.getText().toString());
                myref.child("Linked Case").setValue(edtlinked.getText().toString());
                myref.child("Case Type").setValue(spinner1.getSelectedItem().toString());
                myref.child("Body").setValue(spinner2.getSelectedItem().toString());
                myref.child("Ministry").setValue(spinner3.getSelectedItem().toString());
                myref.child("Department").setValue(spinner4.getSelectedItem().toString());

            }
        });
    }
}
