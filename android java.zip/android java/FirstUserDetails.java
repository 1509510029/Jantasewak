package com.example.deepak.projectpart1;

public class FirstUserDetails {
    private String fname,mname,lname,fathername,mothername,birth;
    private int age;

    public FirstUserDetails(){

    }

    public FirstUserDetails(String fname, String mname, String lname, String fathername, String mothername, String birth, int age) {
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
        this.fathername = fathername;
        this.mothername = mothername;
        this.birth = birth;
        this.age = age;
    }

    public String getFname() {
        return fname;
    }

    public String getMname() {
        return mname;
    }

    public String getLname() {
        return lname;
    }

    public String getFathername() {
        return fathername;
    }

    public String getMothername() {
        return mothername;
    }

    public String getBirth() {
        return birth;
    }

    public int getAge() {
        return age;
    }
}
