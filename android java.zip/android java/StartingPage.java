package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class StartingPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_page);
    }

    public void click(View view) {
        Intent i= new Intent(this,GetOtp.class);
        startActivity(i);
    }

    public void signin(View view) {
        Intent i= new Intent(this,End_user.class);
        startActivity(i);
    }
}
