package com.example.deepak.projectpart1;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class End_user extends AppCompatActivity implements View.OnClickListener {
    private Button buttonsignin;
    private EditText editTextname;
    private EditText editTextpass;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_user);
        FirebaseApp.initializeApp(this);
        mAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);
        buttonsignin = (Button) findViewById(R.id.btnsign);
        editTextname = (EditText) findViewById(R.id.editemail);
        editTextpass = (EditText) findViewById(R.id.editpass);

        buttonsignin.setOnClickListener(End_user.this);
        /*buttonsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
    }

    private void loginUser() {
        String email = editTextname.getText().toString().trim();
        String password = editTextpass.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            //email is empty
            Toast.makeText(this, "please enter email", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }
        if (TextUtils.isEmpty(password) || password.length()<8) {
            //email is empty
            Toast.makeText(this, "please enter correct password", Toast.LENGTH_SHORT).show();
            //stopping the function execution further
            return;
        }
        progressDialog.setMessage("Registering User...");
        progressDialog.show();
        mAuth.createUserWithEmailAndPassword(email, password).
                addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //start profile Activity
                            progressDialog.dismiss();
                            Toast.makeText(End_user.this, "Registered Sucessfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(End_user.this, "Could not Register...", Toast.LENGTH_SHORT).show();
                            progressDialog.dismiss();
                        }
                    }
                });
    }
    public void onClick(View view)
    {
        if(view == buttonsignin)
        {
            String validemail = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +

                    "\\@" +

                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +

                    "(" +

                    "\\." +

                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +

                    ")+";
            String email = editTextname.getText().toString();
            Matcher matcher = Pattern.compile(validemail).matcher(email);
            if (matcher.matches()) {
                loginUser();
                //Toast.makeText(getApplicationContext(),"true",Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Enter valid Mail", Toast.LENGTH_LONG).show();
            }
            if (editTextpass.getText().toString().equals("")) {
                editTextpass.setError("Enter Password");
            }
            //loginUser();
        }
    }
        @Override
        public void onPointerCaptureChanged ( boolean hasCapture){

        }
    }