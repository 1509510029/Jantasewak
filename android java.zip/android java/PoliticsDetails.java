package com.example.deepak.projectpart1;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PoliticsDetails extends AppCompatActivity {
    Button buttonpolitics;
    EditText editText1;
    EditText editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_politics_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button buttonpolitics = (Button)findViewById(R.id.politicssave);
        editText1 = (EditText)findViewById(R.id.currentport);
        editText2 = (EditText)findViewById(R.id.porthandle);

        final EditText editText3=(EditText)findViewById(R.id.currentport);
        final EditText editText4=(EditText)findViewById(R.id.porthandle);
        final Spinner spinner = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr2);

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Political_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.YearPassing_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter1);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/Politicsdetails").child(uid).child("Politics");
        buttonpolitics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savepolitics();
                myref.child("Current portfolio").setValue(editText3.getText().toString());
                myref.child("Portfolio handled").setValue(editText4.getText().toString());
                myref.child("Political party").setValue(spinner.getSelectedItem().toString());
                myref.child("Year of joining").setValue(spinner1.getSelectedItem().toString());
            }
        });
    }
    private void savepolitics(){
        String current= editText1.getText().toString().trim();
        String handle = editText2.getText().toString().trim();
        if(TextUtils.isEmpty(current) || TextUtils.isEmpty(handle)){
            //email is empty
            Toast.makeText(this,"please fill all details ",Toast.LENGTH_LONG).show();
            //stopping the function execution further
            return;

        }
        else{
            Intent i=new Intent(this,PersonalDetails.class);
            startActivity(i);
        }

    }
}