package com.example.deepak.projectpart1;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FamilyDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final Spinner spinner = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr2);
        final Spinner spinner2 = (Spinner) findViewById(R.id.spnr3);
        final Spinner spinner3 = (Spinner) findViewById(R.id.spnr4);
        final Spinner spinner4 = (Spinner) findViewById(R.id.spnr5);
        final Spinner spinner5 = (Spinner) findViewById(R.id.spnr6);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Religion_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Cast_array, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.Children_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter2);
        spinner4.setAdapter(adapter2);
        spinner5.setAdapter(adapter2);

        final EditText edtfname = (EditText)findViewById(R.id.familyfname);
        final EditText edmname = (EditText)findViewById(R.id.familymname);
        final EditText edtlname = (EditText)findViewById(R.id.familylname);
        final EditText edtbirthplace = (EditText)findViewById(R.id.familybirthplace);
        final EditText edtprofession = (EditText)findViewById(R.id.familyprofession);
        final EditText edtqualification = (EditText)findViewById(R.id.familyQualification);
        final EditText edtmobile = (EditText)findViewById(R.id.familyMobileno);
        final EditText edtemail = (EditText)findViewById(R.id.familyemailid);

        Button buttonsave = findViewById(R.id.familybtnsave);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/Familydetails").child(uid).child("Family");
        buttonsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("Spouse First name").setValue(edtfname.getText().toString());
                myref.child("Spouse Middle name").setValue(edmname.getText().toString());
                myref.child("Spouse Last name").setValue(edtlname.getText().toString());
                myref.child("Birth place").setValue(edtbirthplace.getText().toString());
                myref.child("Profession").setValue(edtprofession.getText().toString());
                myref.child("Qualification").setValue(edtqualification.getText().toString());
                myref.child("Mobile no").setValue(edtmobile.getText().toString());
                myref.child("Email ID").setValue(edtemail.getText().toString());
                myref.child("Religion").setValue(spinner1.getSelectedItem().toString());
                myref.child("Cast").setValue(spinner2.getSelectedItem().toString());
                myref.child("Daughter").setValue(spinner3.getSelectedItem().toString());
                myref.child("Son").setValue(spinner4.getSelectedItem().toString());
                myref.child("No of sibling").setValue(spinner5.getSelectedItem().toString());
            }
        });
    }
}
