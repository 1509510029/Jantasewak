package com.example.deepak.projectpart1;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.RecyclerViewHolder> {

    Context context;
    List<ModelClass> itemlist;

    public RecyclerAdapter(Context context, List<ModelClass> itemlist) {
        this.context = context;
        this.itemlist = itemlist;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.case_list_item,viewGroup, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder recyclerViewHolder, int i) {
        recyclerViewHolder.txt1.setText(itemlist.get(i).getTxt1());
        recyclerViewHolder.txt2.setText(itemlist.get(i).getTxt2());
        recyclerViewHolder.txt3.setText(itemlist.get(i).getTxt3());
        recyclerViewHolder.txt4.setText(itemlist.get(i).getTxt4());
        recyclerViewHolder.txt5.setText(itemlist.get(i).getTxt5());
        recyclerViewHolder.txt6.setText(itemlist.get(i).getTxt6());
    }

    @Override
    public int getItemCount() {
        return itemlist.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder{
        TextView txt1,txt2,txt3,txt4,txt5,txt6;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            txt1 = (TextView) itemView.findViewById(R.id.text1);
            txt2 = (TextView) itemView.findViewById(R.id.text2);
            txt3 = (TextView) itemView.findViewById(R.id.text3);
            txt4 = (TextView) itemView.findViewById(R.id.text4);
            txt5 = (TextView) itemView.findViewById(R.id.text5);
            txt6 = (TextView) itemView.findViewById(R.id.text6);
        }
    }
}