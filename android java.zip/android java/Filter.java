package com.example.deepak.projectpart1;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Filter extends AppCompatActivity {

    private ExpandableListView listView;
    private ExpandableListAdapter listAdapter;
    private List<String> listDataHeader;
    private HashMap<String, List<String>> listHash;
    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_apply:
                    mTextMessage.setText(R.string.title_apply);
                    return true;
                case R.id.navigation_clear:
                    mTextMessage.setText(R.string.title_cancel);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);
        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        listView = (ExpandableListView)findViewById(R.id.expandable);
        initData();
        listAdapter = new ExpandableListAdapter(this,listDataHeader,listHash);
        listView.setAdapter(listAdapter);
    }

    private void initData() {
        listDataHeader = new ArrayList<>();
        listHash = new HashMap<>();

        listDataHeader.add("Department");
        listDataHeader.add("Status");
        listDataHeader.add("Priority");
        listDataHeader.add("Type");

        List<String> Dept=new ArrayList<>();
        Dept.add("Central Government");
        Dept.add("State Government");
        Dept.add("Local Body");

        List<String> stat = new ArrayList<>();
        stat.add("Registered");
        stat.add("Pending");
        stat.add("Rejected");
        stat.add("Inprocess");
        stat.add("Complete");
        stat.add("Rejected");
        stat.add("Inprocess");
        stat.add("Complete");

        List<String> Prior = new ArrayList<>();
        Prior.add("low");
        Prior.add("Medium");
        Prior.add("High");

        List<String> typ = new ArrayList<>();
        typ.add("Water");
        typ.add("Electricity");
        typ.add("Civil");

        listHash.put(listDataHeader.get(0),Dept);
        listHash.put(listDataHeader.get(1),stat);
        listHash.put(listDataHeader.get(2),Prior);
        listHash.put(listDataHeader.get(3),typ);
    }
}
