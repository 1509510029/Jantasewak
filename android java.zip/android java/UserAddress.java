package com.example.deepak.projectpart1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserAddress extends AppCompatActivity {
    private EditText editTextPermanentAdd1;
    private EditText editTextPermanentAdd2;
    private EditText getEditTextPermanentPin;
    private EditText editTextPresentAdd1;
    private EditText editTextPresentAdd2;
    private EditText getEditTextPresentPin;
    private CheckBox checkBox1;
    private Spinner getspinner1;
    private Spinner getspinner2;
    private Spinner getspinner3;
    private Spinner getspinner4;
    private Button buttonsave;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_address);
        final Spinner spinner1 = (Spinner) findViewById(R.id.spnr1);
        final Spinner spinner2 = (Spinner) findViewById(R.id.spnr2);
        final Spinner spinner3 = (Spinner) findViewById(R.id.spnr3);
        final Spinner spinner4 = (Spinner) findViewById(R.id.spnr4);
        // Create an ArrayAdapter using the string array and a default spinner layout
        final ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.District_array, android.R.layout.simple_spinner_item);
        final ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.State_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter1);
        spinner4.setAdapter(adapter2);

        editTextPermanentAdd1 = findViewById(R.id.userpermaAdd1);
        editTextPermanentAdd2 = findViewById(R.id.userpermaAdd2);
        getEditTextPermanentPin = findViewById(R.id.userpermaPin);
        editTextPermanentAdd2 = findViewById(R.id.userpermaAdd2);
        getEditTextPermanentPin = findViewById(R.id.userpermaPin);
        editTextPresentAdd1 = findViewById(R.id.userpresAddress1);
        editTextPresentAdd2 = findViewById(R.id.userpresAddress2);
        getEditTextPresentPin = findViewById(R.id.userprespin);
        checkBox1 = findViewById(R.id.same);
        getspinner1 = findViewById(R.id.spnr1);
        getspinner2 = findViewById(R.id.spnr2);
        getspinner3 = findViewById(R.id.spnr3);
        getspinner4 = findViewById(R.id.spnr4);
        buttonsave = findViewById(R.id.userbuttonsave);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();
        String uid = current_user.getUid();
        final DatabaseReference myref=database.getReferenceFromUrl("https://projectpart1-6af65.firebaseio.com/userpersonaldetails").child(uid).child("Address");
        // editTextPermanentAdd1.addTextChangedListener(loginTextWatcher);
        //editTextPermanentAdd1.addTextChangedListener(loginTextWatcher);
        checkBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String FirstAddress1= editTextPermanentAdd1.getText().toString().trim();
                editTextPresentAdd1.setText(FirstAddress1);
                String SecondAddress2 = editTextPermanentAdd2.getText().toString().trim();
                editTextPresentAdd2.setText(SecondAddress2);
                String SetPincode= getEditTextPermanentPin.getText().toString().trim();
                getEditTextPresentPin.setText(SetPincode);
                String SecondSpinner= getspinner2.getSelectedItem().toString().trim();
                getspinner4.setAdapter(adapter2);
            }
        });
        buttonsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("Address Line1").setValue(editTextPermanentAdd1.getText().toString());
                myref.child("Address Line2").setValue(editTextPermanentAdd2.getText().toString());
                myref.child("Pincode").setValue(getEditTextPermanentPin.getText().toString());
                myref.child("Present District").setValue(spinner1.getSelectedItem().toString());
                myref.child("Present State").setValue(spinner2.getSelectedItem().toString());
                myref.child("Permanent District").setValue(spinner3.getSelectedItem().toString());
                myref.child("Permanent State").setValue(spinner4.getSelectedItem().toString());
                loginUser();
            }
        });
    }
    private void loginUser() {
        String Address1= editTextPermanentAdd1.getText().toString().trim();
        String Address2 = editTextPermanentAdd2.getText().toString().trim();
        String Pincode1= getEditTextPermanentPin.getText().toString().trim();
        String Address3 = editTextPresentAdd1.getText().toString().trim();
        String Address4= editTextPresentAdd2.getText().toString().trim();
        String Pincode2 = getEditTextPresentPin.getText().toString().trim();

        if(TextUtils.isEmpty(Address1) || TextUtils.isEmpty(Address2)|| TextUtils.isEmpty(Pincode1)|| TextUtils.isEmpty(Address3)
                || TextUtils.isEmpty(Address4)|| TextUtils.isEmpty(Pincode2)){
            //email is empty
            Toast.makeText(this,"please fill all details ",Toast.LENGTH_LONG).show();
            //stopping the function execution further
            return;

        }
        else{
            Intent i=new Intent(this,UserPersonalDetails.class);
            startActivity(i);
        }

    }

   /* private TextWatcher loginTextWatcher =new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            String Address1= editTextPermanentAdd1.getText().toString().trim();
            String Address2= editTextPermanentAdd2.getText().toString().trim();
            buttonsave.setEnabled(!Address1.isEmpty() && !Address2.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };*/
}
